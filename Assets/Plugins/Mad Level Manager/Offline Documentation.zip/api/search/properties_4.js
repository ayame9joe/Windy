var searchData=
[
  ['recentlevelselected',['recentLevelSelected',['../class_mad_level_manager_1_1_mad_level_profile.html#aac010b459114d53d157b52e32ff8a852',1,'MadLevelManager::MadLevelProfile']]]
];
