var searchData=
[
  ['lastplayedlevelname',['lastPlayedLevelName',['../class_mad_level_manager_1_1_mad_level.html#ad6f1f000bbbde0f6948091f2656c9c6d',1,'MadLevelManager::MadLevel']]],
  ['level',['level',['../class_mad_level_manager_1_1_mad_level_icon.html#a38790ca700417ceead76ba46fa2eb18e',1,'MadLevelManager::MadLevelIcon']]]
];
